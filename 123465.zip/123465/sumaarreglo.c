#include <stdio.h>

void sumarArregloEscalar(float *arreglo, int tamanio, float escalar) {
    for (int i = 0; i < tamanio; i++) {
        arreglo[i] += escalar;
    }
}

int main(void) {
    float arreglo[5];
    float escalar;

    printf("Ingrese 5 numeros para el arreglo:\n");
    for (int i = 0; i < 5; i++) {
        printf("Ingrese el numero %d: ", i + 1);
        scanf("%f", &arreglo[i]);
    }

    printf("Ingrese el escalar: ");
    scanf("%f", &escalar);

    sumarArregloEscalar(arreglo, 5, escalar);

    printf("Arreglo resultante despues de la primera suma:\n");
    for (int i = 0; i < 5; i++) {
        printf("%.2f ", arreglo[i]);
    }
    printf("\n");

    sumarArregloEscalar(arreglo, 5, arreglo[0]); // Sumar el resultado de la primera suma con los 5 numeros

    printf("Arreglo resultante despues de la segunda suma:\n");
    for (int i = 0; i < 5; i++) {
        printf("%.2f ", arreglo[i]);
    }
    printf("\n");

    return 0;
}
